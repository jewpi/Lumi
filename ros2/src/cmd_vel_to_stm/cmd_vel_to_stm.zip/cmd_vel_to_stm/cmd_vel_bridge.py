import struct

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

import serial


class CmdVelBridge(Node):
    """Subscribe /cmd_vel and forward linear.x / angular.z to STM32 over UART.

    Packet format: struct.pack('<ff', linear_x, angular_z) — 8 bytes, Little-Endian.
    """

    def __init__(self):
        super().__init__('cmd_vel_bridge')

        # 파라미터 선언 (launch/CLI에서 변경 가능)
        self.declare_parameter('serial_port', '/dev/ttyUSB0')
        self.declare_parameter('baudrate', 115200)
        self.declare_parameter('cmd_vel_topic', '/cmd_vel')
        # 이 시간(초) 동안 /cmd_vel이 안 들어오면 정지 패킷 전송. 0 이하면 비활성화.
        self.declare_parameter('cmd_timeout', 0.5)

        port = self.get_parameter('serial_port').value
        baudrate = self.get_parameter('baudrate').value
        topic = self.get_parameter('cmd_vel_topic').value
        self.cmd_timeout = float(self.get_parameter('cmd_timeout').value)

        # UART 오픈
        try:
            self.ser = serial.Serial(port, baudrate, timeout=1)
        except serial.SerialException as e:
            self.get_logger().fatal(f'Failed to open serial port {port}: {e}')
            raise

        self.get_logger().info(f'Connected to {port} at {baudrate} bps')

        self.subscription = self.create_subscription(
            Twist, topic, self.cmd_vel_callback, 10)
        self.get_logger().info(f'Subscribed to {topic}')

        # watchdog: cmd_vel이 끊기면 정지 명령 전송
        self.last_cmd_time = self.get_clock().now()
        self.stopped = True
        if self.cmd_timeout > 0.0:
            self.watchdog_timer = self.create_timer(0.1, self.watchdog_callback)

    def send_packet(self, linear_x: float, angular_z: float):
        packet = struct.pack('<ff', linear_x, angular_z)
        try:
            self.ser.write(packet)
        except serial.SerialException as e:
            self.get_logger().error(f'Serial write failed: {e}')
            return
        self.get_logger().debug(
            f'Sent -> Lin_X: {linear_x:.2f}, Ang_Z: {angular_z:.2f} (8 Bytes)')

    def cmd_vel_callback(self, msg: Twist):
        self.last_cmd_time = self.get_clock().now()
        self.stopped = False
        self.send_packet(msg.linear.x, msg.angular.z)

    def watchdog_callback(self):
        if self.stopped:
            return
        elapsed = (self.get_clock().now() - self.last_cmd_time).nanoseconds * 1e-9
        if elapsed > self.cmd_timeout:
            self.get_logger().warn(
                f'No /cmd_vel for {elapsed:.2f}s -> sending stop command')
            self.send_packet(0.0, 0.0)
            self.stopped = True

    def destroy_node(self):
        # 종료 시 정지 패킷을 보내고 포트를 닫음
        if hasattr(self, 'ser') and self.ser.is_open:
            try:
                self.send_packet(0.0, 0.0)
                self.ser.close()
                self.get_logger().info('Serial port closed.')
            except serial.SerialException:
                pass
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    try:
        node = CmdVelBridge()
    except serial.SerialException:
        rclpy.shutdown()
        return

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
